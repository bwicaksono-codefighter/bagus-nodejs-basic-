var express = require('express');
var logger = require('morgan'); //untuk log
var expressku = require('./routes/expressku');
var conn = require('express-myconnection');
var mysql = require('mysql');
var app = express();

// setting port berdasarkan port environment
app.set('port', process.env.port || 3030);

app.set('view engine', 'ejs');

// memuat middleware morgan untuk log
app.use(logger('dev'));
// memuat middleware static
// path '/public' sebagai parameter root directory , dengan menambahkannya sebagai parameter masukan
app.use('/public', express.static(__dirname + '/public'));

// konek ke database mysql
app.use(
    conn(mysql, {
        host: 'localhost',
        user: 'root',
        password: '',
        port: 3306,
        database: 'ecommerce_express'
    }, 'single')
);

app.get('/', function (req, res) {
    res.send('Server is running on port ' + app.get('port'));
});

// menangani request untuk path '/express'
app.get('/express', expressku.index);
// menangani request untuk path '/express/products'
app.get('/express/detail_product/:id_product', expressku.detail_product);

app.listen(app.get('port'), function () {
    console.log('Server is running on port ' + app.get('port'));
});