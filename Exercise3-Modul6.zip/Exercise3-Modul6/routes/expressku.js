
// fungsi untuk merender template index.ejs ketika dipanggil
exports.index = function (req, res) {
    req.getConnection(function (err, connect) {
        var query = connect.query('SELECT * FROM product', function (err, rows) {
            if (err) {
                console.log('Error message: %', err);
            }
            // render template products.ejs pada folder views
            res.render('index', {
                page_title: 'Luxury Watches Home',
                data: rows
            });
        });
    });
}

// fungsi untuk merender template products.ejs ketika dipanggil
exports.detail_product = function (req, res) {
    // ambil nilai id_product dari link
    var id_product = req.params.id_product;

    req.getConnection(function (err, connect) {
        var sql = "SELECT * FROM product WHERE id_product=?";

        var query = connect.query(sql, id_product, function (err, results) {
            if (err) {
                console.log('Error show product : %s', err);
            }
            res.render('detail_product', {
                id_product: id_product,
                pathname: 'detail_product',
                data: results
            });
        });
    });
}