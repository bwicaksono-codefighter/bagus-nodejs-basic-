var mysql = require('mysql');

// konek ke database
var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ecommerce"
});

connection.connect(function (err) {
    if (err) {
        throw err;
    }
    console.log("Terkoneksi dengan Sukses");

    // query untuk insert dan masukkan ke dalam variabel
    var sql1 = "INSERT INTO product(id_produk, nama_produk, gambar_produk, harga_produk, des_produk, createdate) VALUES(1, 'Sepatu Sneaker', 'sneaker.jpg', 200000, 'Kami menjual sepatu berkualitas berbagai ukuran', '2020-04-08')";

    // query : digunakan untuk menjalankan query pada sql, sehingga bisa untuk memanipulasi database
    connection.query(sql1, function (err, result) {
        if (err) {
            throw err;
        }
        console.log('Data 1 berhasil ditambahkan');
    });

    var sql2 = "INSERT INTO product(id_produk, nama_produk, gambar_produk, harga_produk, des_produk, createdate) VALUES(2, 'Sepatu Pantofel', 'sneaker.jpg', 500000, 'Kami menjual sepatu pantofel 2020', '2020-04-09')";

    connection.query(sql2, function (err, result) {
        if (err) {
            throw err;
        }
        console.log('Data 2 berhasil ditambahkan');
        // destroy : menghentikan proses query
        connection.destroy();
    });
});
