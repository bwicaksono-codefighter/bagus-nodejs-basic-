var mysql = require('mysql');

// konek ke database
var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ecommerce"
});

connection.connect(function (err) {
    if (err) {
        throw err;
    }
    console.log("Terkoneksi dengan Sukses");

    // query untuk membuat table dan masukkan ke dalam variabel
    var sql = "CREATE TABLE product(id_produk INT(11), nama_produk VARCHAR(60), gambar_produk VARCHAR(200), harga_produk INT(13), des_produk TEXT, createdate DATE, PRIMARY KEY(id_produk))";

    // query : digunakan untuk menjalankan query pada sql, sehingga bisa untuk memanipulasi database
    connection.query(sql, function (err, result) {
        if (err) {
            throw err;
        }
        console.log('Tabel berhasil dibuat');
        // destroy : menghentikan proses query
        connection.destroy();
    });
});
