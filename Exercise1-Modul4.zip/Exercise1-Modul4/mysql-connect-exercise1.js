var mysql = require('mysql');

var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: ""
});

connection.connect(function (err) {
    if (err) {
        console.error('error connect' + err.stack);
    }

    console.log("Telah terkoneksi ke database mysql dengan id" + connection.threadId);
});