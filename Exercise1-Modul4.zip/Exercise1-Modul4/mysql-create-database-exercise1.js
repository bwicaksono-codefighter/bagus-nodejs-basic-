var mysql = require('mysql');

// konek ke mysql database
var connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: ""
});

// periksa koneksi  
connection.connect(function (err) {
    if (err) {
        throw err;
    }
    console.log("Terkoneksi dengan Sukses");

    // query : digunakan untuk menjalankan query pada sql, sehingga bisa untuk memanipulasi database
    connection.query('CREATE DATABASE ecommerce', function (err, result) {
        if (err) {
            throw err;
        }
        console.log('Database telah dibuat');
        // destroy : menghentikan proses query
        connection.destroy();
    })
});