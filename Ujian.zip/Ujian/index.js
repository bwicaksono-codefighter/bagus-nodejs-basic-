var express = require('express');
var logger = require('morgan'); //untuk log
var path = require('path');
var expressku = require('./routes/expressku'); //memanggil modul expressku
var adminku = require('./routes/adminku'); //memanggil modul adminku
var conn = require('express-myconnection');
var mysql = require('mysql');
var app = express();
var bodyParser = require('body-parser');
var session = require('express-session')
var flash = require('express-flash');

// setting port berdasarkan port environment
app.set('port', process.env.port || 3030);

app.set('view engine', 'ejs');

// memuat middleware morgan untuk log
app.use(logger('dev'));
// path '/public' sebagai parameter root directory , dengan menambahkannya sebagai parameter masukan
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({extended: false}));

app.use(flash());

// konek ke database mysql
app.use(
    conn(mysql, {
        host: 'localhost',
        user: 'root',
        password: '',
        port: 3306,
        database: 'ecommerce_express'
    }, 'single')
);

// buat session
app.use(
    session({
        secret: 'baguswicaksono',
        resave: false,
        saveUninitialized: true,
        cookie: {maxAge: 120000}
    })
);

app.get('/', function (req, res) {
    res.send('Server is running on port ' + app.get('port'));
});

// menangani request untuk path '/express'
app.get('/express', expressku.index);
// menangani request untuk path '/express/products'
app.get('/express/detail_product/:id_product', expressku.detail_product);

// route untuk method login pada modul 'adminku'
app.get('/express/admin', adminku.home);
app.get('/express/admin/login', adminku.login);

app.post('/express/admin/login', adminku.login)

// route untuk method home pada modul 'adminku'
app.get('/express/admin/home', adminku.home);

// route untuk method add_produk pada modul 'adminku'
app.get('/express/admin/add_produk', adminku.add_produk);

// route post untuk menangani input produk
app.post('/express/admin/add_produk', adminku.process_add_produk);

// route untuk method edit_produk pada modul 'adminku' dengan membawa parameter id_product
app.get('/express/admin/edit_produk/:id_product', adminku.edit_produk);

// route post untuk menangani edit produk
app.post('/express/admin/edit_produk/:id_product', adminku.process_edit_produk);

// route untuk method delete_produk pada modul 'adminku' dengan membawa parameter id_product
app.get('/express/admin/delete_produk/:id_product', adminku.delete_produk);

// logout
app.get('/express/admin/logout', adminku.logout);

app.listen(app.get('port'), function () {
    console.log('Server is running on port ' + app.get('port'));
});